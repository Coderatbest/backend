-- Adminer 4.8.1 MySQL 5.5.5-10.7.1-MariaDB-1:10.7.1+maria~focal dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `authtoken_token`;
CREATE TABLE `authtoken_token` (
  `key` varchar(40) NOT NULL,
  `created` datetime(6) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `authtoken_token_user_id_35299eff_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `authtoken_token` (`key`, `created`, `user_id`) VALUES
('69b1efb495e59b34d7b508f887527b10720f6d80',	'2021-12-24 02:46:35.762416',	2);

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1,	'Can add log entry',	1,	'add_logentry'),
(2,	'Can change log entry',	1,	'change_logentry'),
(3,	'Can delete log entry',	1,	'delete_logentry'),
(4,	'Can view log entry',	1,	'view_logentry'),
(5,	'Can add permission',	2,	'add_permission'),
(6,	'Can change permission',	2,	'change_permission'),
(7,	'Can delete permission',	2,	'delete_permission'),
(8,	'Can view permission',	2,	'view_permission'),
(9,	'Can add group',	3,	'add_group'),
(10,	'Can change group',	3,	'change_group'),
(11,	'Can delete group',	3,	'delete_group'),
(12,	'Can view group',	3,	'view_group'),
(13,	'Can add content type',	4,	'add_contenttype'),
(14,	'Can change content type',	4,	'change_contenttype'),
(15,	'Can delete content type',	4,	'delete_contenttype'),
(16,	'Can view content type',	4,	'view_contenttype'),
(17,	'Can add session',	5,	'add_session'),
(18,	'Can change session',	5,	'change_session'),
(19,	'Can delete session',	5,	'delete_session'),
(20,	'Can view session',	5,	'view_session'),
(21,	'Can add Token',	6,	'add_token'),
(22,	'Can change Token',	6,	'change_token'),
(23,	'Can delete Token',	6,	'delete_token'),
(24,	'Can view Token',	6,	'view_token'),
(25,	'Can add token',	7,	'add_tokenproxy'),
(26,	'Can change token',	7,	'change_tokenproxy'),
(27,	'Can delete token',	7,	'delete_tokenproxy'),
(28,	'Can view token',	7,	'view_tokenproxy'),
(29,	'Can add user',	8,	'add_user'),
(30,	'Can change user',	8,	'change_user'),
(31,	'Can delete user',	8,	'delete_user'),
(32,	'Can view user',	8,	'view_user'),
(33,	'Can add profile',	9,	'add_profile'),
(34,	'Can change profile',	9,	'change_profile'),
(35,	'Can delete profile',	9,	'delete_profile'),
(36,	'Can view profile',	9,	'view_profile'),
(37,	'Can add commentaries models',	10,	'add_commentariesmodels'),
(38,	'Can change commentaries models',	10,	'change_commentariesmodels'),
(39,	'Can delete commentaries models',	10,	'delete_commentariesmodels'),
(40,	'Can view commentaries models',	10,	'view_commentariesmodels'),
(41,	'Can add posts models',	11,	'add_postsmodels'),
(42,	'Can change posts models',	11,	'change_postsmodels'),
(43,	'Can delete posts models',	11,	'delete_postsmodels'),
(44,	'Can view posts models',	11,	'view_postsmodels'),
(45,	'Can add visits models',	12,	'add_visitsmodels'),
(46,	'Can change visits models',	12,	'change_visitsmodels'),
(47,	'Can delete visits models',	12,	'delete_visitsmodels'),
(48,	'Can view visits models',	12,	'view_visitsmodels'),
(49,	'Can add images profile',	13,	'add_imagesprofile'),
(50,	'Can change images profile',	13,	'change_imagesprofile'),
(51,	'Can delete images profile',	13,	'delete_imagesprofile'),
(52,	'Can view images profile',	13,	'view_imagesprofile'),
(53,	'Can add time line profile',	14,	'add_timelineprofile'),
(54,	'Can change time line profile',	14,	'change_timelineprofile'),
(55,	'Can delete time line profile',	14,	'delete_timelineprofile'),
(56,	'Can view time line profile',	14,	'view_timelineprofile');

DROP TABLE IF EXISTS `commentaries_commentariesmodels`;
CREATE TABLE `commentaries_commentariesmodels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_activate` tinyint(1) NOT NULL,
  `date_created` date NOT NULL,
  `date_modified` date DEFAULT NULL,
  `body` longtext NOT NULL,
  `user_created_id` bigint(20) DEFAULT NULL,
  `user_modified_id` bigint(20) DEFAULT NULL,
  `answers_to_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commentaries_comment_user_created_id_0162cd0b_fk_users_use` (`user_created_id`),
  KEY `commentaries_comment_user_modified_id_e8d1796e_fk_users_use` (`user_modified_id`),
  KEY `commentaries_comment_answers_to_id_269fd728_fk_commentar` (`answers_to_id`),
  CONSTRAINT `commentaries_comment_answers_to_id_269fd728_fk_commentar` FOREIGN KEY (`answers_to_id`) REFERENCES `commentaries_commentariesmodels` (`id`),
  CONSTRAINT `commentaries_comment_user_created_id_0162cd0b_fk_users_use` FOREIGN KEY (`user_created_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `commentaries_comment_user_modified_id_e8d1796e_fk_users_use` FOREIGN KEY (`user_modified_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_users_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(4,	'2022-02-03 04:08:27.813791',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Age\"]}}]',	9,	2),
(5,	'2022-02-03 04:24:08.364581',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(6,	'2022-02-03 04:31:25.425958',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(7,	'2022-02-04 03:45:04.045088',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(8,	'2022-02-04 03:48:47.373768',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(9,	'2022-02-04 03:55:58.465383',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(10,	'2022-02-04 03:56:16.789911',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(11,	'2022-02-04 03:59:22.122931',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(12,	'2022-02-04 03:59:40.829611',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(13,	'2022-02-04 04:00:36.457712',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(14,	'2022-02-04 04:01:05.179155',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(15,	'2022-02-04 04:05:41.017370',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(16,	'2022-02-04 04:13:30.566327',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(17,	'2022-02-08 04:51:52.687278',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(18,	'2022-02-08 04:52:07.079783',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Profile picture\"]}}]',	9,	2),
(19,	'2022-02-08 04:55:38.745785',	'1',	'Profile object (1)',	2,	'[{\"changed\": {\"fields\": [\"Biography\"]}}, {\"added\": {\"name\": \"images profile\", \"object\": \"https://res.cloudinary.com/dd7jrtxu5/image/upload/v1/media/images/users/profile/imgs_extra/imagen_cjbso3_itah5l\"}}, {\"added\": {\"name\": \"time line profile\", \"object\": \"TimeLineProfile object (1)\"}}, {\"added\": {\"name\": \"time line profile\", \"object\": \"TimeLineProfile object (2)\"}}, {\"added\": {\"name\": \"time line profile\", \"object\": \"TimeLineProfile object (3)\"}}, {\"added\": {\"name\": \"time line profile\", \"object\": \"TimeLineProfile object (4)\"}}]',	9,	2),
(21,	'2022-05-29 23:18:45.178486',	'3',	'admin',	3,	'',	8,	2);

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1,	'admin',	'logentry'),
(3,	'auth',	'group'),
(2,	'auth',	'permission'),
(6,	'authtoken',	'token'),
(7,	'authtoken',	'tokenproxy'),
(10,	'commentaries',	'commentariesmodels'),
(4,	'contenttypes',	'contenttype'),
(11,	'posts',	'postsmodels'),
(5,	'sessions',	'session'),
(13,	'users',	'imagesprofile'),
(9,	'users',	'profile'),
(14,	'users',	'timelineprofile'),
(8,	'users',	'user'),
(12,	'visits',	'visitsmodels');

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1,	'contenttypes',	'0001_initial',	'2021-12-22 03:11:21.092320'),
(2,	'contenttypes',	'0002_remove_content_type_name',	'2021-12-22 03:11:21.709922'),
(3,	'auth',	'0001_initial',	'2021-12-22 03:11:23.416652'),
(4,	'auth',	'0002_alter_permission_name_max_length',	'2021-12-22 03:11:23.714054'),
(5,	'auth',	'0003_alter_user_email_max_length',	'2021-12-22 03:11:23.879365'),
(6,	'auth',	'0004_alter_user_username_opts',	'2021-12-22 03:11:24.058131'),
(7,	'auth',	'0005_alter_user_last_login_null',	'2021-12-22 03:11:24.247522'),
(8,	'auth',	'0006_require_contenttypes_0002',	'2021-12-22 03:11:24.386528'),
(9,	'auth',	'0007_alter_validators_add_error_messages',	'2021-12-22 03:11:24.589934'),
(10,	'auth',	'0008_alter_user_username_max_length',	'2021-12-22 03:11:24.743581'),
(11,	'auth',	'0009_alter_user_last_name_max_length',	'2021-12-22 03:11:24.913736'),
(12,	'auth',	'0010_alter_group_name_max_length',	'2021-12-22 03:11:25.166089'),
(13,	'auth',	'0011_update_proxy_permissions',	'2021-12-22 03:11:25.514985'),
(14,	'auth',	'0012_alter_user_first_name_max_length',	'2021-12-22 03:11:25.727053'),
(15,	'users',	'0001_initial',	'2021-12-22 03:11:29.984756'),
(16,	'admin',	'0001_initial',	'2021-12-22 03:11:31.272802'),
(17,	'admin',	'0002_logentry_remove_auto_add',	'2021-12-22 03:11:31.621301'),
(18,	'admin',	'0003_logentry_add_action_flag_choices',	'2021-12-22 03:11:31.886815'),
(19,	'authtoken',	'0001_initial',	'2021-12-22 03:11:33.056608'),
(20,	'authtoken',	'0002_auto_20160226_1747',	'2021-12-22 03:11:33.319437'),
(21,	'authtoken',	'0003_tokenproxy',	'2021-12-22 03:11:33.549413'),
(22,	'commentaries',	'0001_initial',	'2021-12-22 03:11:35.135047'),
(23,	'commentaries',	'0002_commentariesmodels_answers_to',	'2021-12-22 03:11:35.821827'),
(24,	'posts',	'0001_initial',	'2021-12-22 03:11:37.945251'),
(25,	'sessions',	'0001_initial',	'2021-12-22 03:11:38.760743'),
(26,	'visits',	'0001_initial',	'2021-12-22 03:11:40.185820'),
(27,	'users',	'0002_profile_age',	'2022-02-03 03:41:10.896964'),
(28,	'users',	'0003_alter_profile_biography',	'2022-02-03 03:41:11.089356'),
(29,	'users',	'0004_alter_profile_biography',	'2022-02-03 03:41:11.328990'),
(30,	'users',	'0005_auto_20220203_0422',	'2022-02-03 04:22:30.635718'),
(31,	'users',	'0006_auto_20220204_0547',	'2022-02-08 03:44:26.487905'),
(32,	'users',	'0007_rename_imgs_extra_imagesprofile_profile',	'2022-02-08 03:44:26.550302'),
(33,	'users',	'0008_alter_imagesprofile_image',	'2022-02-08 03:44:26.580123'),
(34,	'users',	'0009_timelineprofile',	'2022-02-08 03:44:26.641137'),
(35,	'users',	'0010_auto_20220205_0526',	'2022-02-08 03:44:26.672112');

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('3pomlcbij4585l98yts1fv4okm6tvlvt',	'.eJxVjDsOwjAQRO_iGll2_A0lfc4QrXfXOIBsKZ8KcXcSKQWUM-_NvMUI21rGbeF5nEhcRScuv10CfHI9AD2g3pvEVtd5SvJQ5EkXOTTi1-10_w4KLGVf9-wMk3ZIaEkBW9TBgCFPiNpm70LaQ8o6h9ixyb5XWUNUXqscbUri8wUHWDiL:1nvSAn:1SdWpS1AUzypxcuFPnES5Wy8cGkSJTmEpOhPenLSJNg',	'2022-06-12 23:18:13.280911'),
('4sbcb099vll6m5c1qcx7kobzog4im481',	'.eJxVjEEOwiAQRe_C2hAGAjgu3XsGMjAgVQNJaVeNd9cmXej2v_f-JgKtSw3ryHOYWFwEiNPvFik9c9sBP6jdu0y9LfMU5a7Igw5565xf18P9O6g06rdGXUpCpQBQGW8zJFbFAmo2bIxRzhV0xnvS4LiAZ4zWngFTduBJWfH-ALrDNrc:1n0aKW:_GmVef17uLp9sZEFn93twisk6skvWtXt0FleJjlB4CY',	'2022-01-07 02:29:12.052873'),
('cq4s0vvvl77hbu0x7xtl0bct4i4e2k0j',	'.eJxVjMsOwiAQRf-FtSE8Ci0u3fsNZAZmpGogKe3K-O_apAvd3nPOfYkI21ri1mmJcxZnYcTpd0NID6o7yHeotyZTq-syo9wVedAury3T83K4fwcFevnW5LxFBOM5MapBsyVNRC4HhUplnZQfWY8ZLThncAqDZ8MQJh2QrQbx_gAF-ziD:1nFpyC:kjqdjb8Q1J8m0L7uuOnfc0kjddr0gVE7iSbkdhQEmoU',	'2022-02-18 04:13:12.552426'),
('vro1eyvh3sqrmetj8e6gah74g3a0germ',	'.eJxVjEEOwiAQRe_C2hAYIAMu3XsGAjNUqgaS0q6Md9cmXej2v_f-S8S0rTVuoyxxZnEWIE6_W070KG0HfE_t1iX1ti5zlrsiDzrktXN5Xg7376CmUb-1z2nKgQAw2AxEwRXvJmajtEX2oA1TMEEBeyTntDIaffKYnYHiLIr3B-PENyE:1n7T3W:d-ZQgPQX8MET0OrZ3vpkygHVA4sm8EAd32YCRjq0XkI',	'2022-01-26 02:08:06.371315');

DROP TABLE IF EXISTS `posts_postsmodels`;
CREATE TABLE `posts_postsmodels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_activate` tinyint(1) NOT NULL,
  `date_created` date NOT NULL,
  `date_modified` date DEFAULT NULL,
  `title` longtext NOT NULL,
  `content` longtext NOT NULL,
  `valid_date` date NOT NULL,
  `user_created_id` bigint(20) DEFAULT NULL,
  `user_modified_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_postsmodels_user_created_id_718cdbb7_fk_users_user_id` (`user_created_id`),
  KEY `posts_postsmodels_user_modified_id_bf982afe_fk_users_user_id` (`user_modified_id`),
  CONSTRAINT `posts_postsmodels_user_created_id_718cdbb7_fk_users_user_id` FOREIGN KEY (`user_created_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `posts_postsmodels_user_modified_id_bf982afe_fk_users_user_id` FOREIGN KEY (`user_modified_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `users_imagesprofile`;
CREATE TABLE `users_imagesprofile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image` varchar(100) DEFAULT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_imagesprofile_profile_id_c7c32260_fk_users_profile_id` (`profile_id`),
  CONSTRAINT `users_imagesprofile_profile_id_c7c32260_fk_users_profile_id` FOREIGN KEY (`profile_id`) REFERENCES `users_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users_imagesprofile` (`id`, `image`, `profile_id`) VALUES
(1,	'media/images/users/profile/imgs_extra/imagen_cjbso3_itah5l',	1);

DROP TABLE IF EXISTS `users_profile`;
CREATE TABLE `users_profile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image` varchar(100) DEFAULT NULL,
  `biography` longtext NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `age` int(10) unsigned DEFAULT NULL CHECK (`age` >= 0),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `users_profile_user_id_2112e78d_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users_profile` (`id`, `image`, `biography`, `user_id`, `age`) VALUES
(1,	'media/images/users/profile/imagen_cjbso3_kyyu3y',	'Nacìo el 22 de noviembre de 1996, en San Pedro Sula, Cortes, Honduras. Hijo de Jose Anael Diaz Guevara y Mirian Suyapa Sierra Villamil.\r\nRealizo sus estudios en la escuela Dionisio de Herrera, en el colegio Jose Trinidad Reyes reciviendo asi el Título de BTP en Informatica. En la fecha 03/2019, inicio los Cursos por parte del convenio de la Asosiacion Hondureña de Maquiladores (AHM) y la Fundacion Nacional para el Desarrollo de Honduras (FUNADEH) llamado Academia de Programadores. Participando asi en la segunda promocion.\r\nPara Ingresar en el proyecto anterior, realizo varias pruebas y filtros. Donde recibio una certificacion MTA y MOS.\r\nEn la Actualidad estudia en la Universidad Autonoma De Honduras, Ubicada en el valle de sula (UNAH-VS). A su vez recibe cursos en una plataforma en linea llamada Platzi.\r\nAlex a sus 25 años de edad, tiene pasion por la Fisica (Astronomia, el mundo sub-atòmico, termodinamica, etc), Tecnologia, Matematica,Comedia, Ciencia Ficcion, fantasia, literatura, etc.',	2,	25);

DROP TABLE IF EXISTS `users_timelineprofile`;
CREATE TABLE `users_timelineprofile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `year` int(11) DEFAULT NULL,
  `comment` varchar(300) DEFAULT NULL,
  `icon` varchar(20) NOT NULL,
  `profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_timelineprofile_profile_id_a1166e14_fk_users_profile_id` (`profile_id`),
  CONSTRAINT `users_timelineprofile_profile_id_a1166e14_fk_users_profile_id` FOREIGN KEY (`profile_id`) REFERENCES `users_profile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users_timelineprofile` (`id`, `year`, `comment`, `icon`, `profile_id`) VALUES
(1,	2022,	'hola 2022',	'AiFillHeart',	1),
(2,	2021,	'hola 2021',	'AiFillFire',	1),
(3,	2020,	'hola 2020',	'AiFillGift',	1),
(4,	2019,	'hola 2019',	'AiFillCode',	1);

DROP TABLE IF EXISTS `users_user`;
CREATE TABLE `users_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `is_activate` tinyint(1) NOT NULL,
  `date_created` date NOT NULL,
  `date_modified` date DEFAULT NULL,
  `email` varchar(40) NOT NULL,
  `phone_number` varchar(17) NOT NULL,
  `is_client` tinyint(1) NOT NULL,
  `is_verified` tinyint(1) NOT NULL,
  `user_created_id` bigint(20) DEFAULT NULL,
  `user_modified_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `users_user_user_created_id_db47ac4c_fk_users_user_id` (`user_created_id`),
  KEY `users_user_user_modified_id_c9a63e3f_fk_users_user_id` (`user_modified_id`),
  CONSTRAINT `users_user_user_created_id_db47ac4c_fk_users_user_id` FOREIGN KEY (`user_created_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `users_user_user_modified_id_c9a63e3f_fk_users_user_id` FOREIGN KEY (`user_modified_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `is_staff`, `is_active`, `date_joined`, `is_activate`, `date_created`, `date_modified`, `email`, `phone_number`, `is_client`, `is_verified`, `user_created_id`, `user_modified_id`) VALUES
(2,	'pbkdf2_sha256$260000$TqXJP08xQg4GfumKuFZqNx$hEoTcd5D5YLCoHBz9oR/2dYqaQmtCfiJhaAQD1+4z6E=',	'2022-05-29 23:18:13.278036',	1,	'al3xdiaz',	'alex',	'diaz',	1,	1,	'2021-12-24 02:41:53.000000',	1,	'2021-12-24',	NULL,	'alexleonel96@hotmail.com',	'+1234567890',	1,	1,	NULL,	NULL);

DROP TABLE IF EXISTS `users_user_groups`;
CREATE TABLE `users_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_groups_user_id_group_id_b88eab82_uniq` (`user_id`,`group_id`),
  KEY `users_user_groups_group_id_9afc8d0e_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_user_groups_group_id_9afc8d0e_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `users_user_groups_user_id_5f6f5a90_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `users_user_user_permissions`;
CREATE TABLE `users_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_user_permissions_user_id_permission_id_43338c45_uniq` (`user_id`,`permission_id`),
  KEY `users_user_user_perm_permission_id_0b93982e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_user_user_perm_permission_id_0b93982e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_user_user_permissions_user_id_20aca447_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `visits_visitsmodels`;
CREATE TABLE `visits_visitsmodels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_activate` tinyint(1) NOT NULL,
  `date_created` date NOT NULL,
  `date_modified` date DEFAULT NULL,
  `ip_adreess` longtext NOT NULL,
  `user_created_id` bigint(20) DEFAULT NULL,
  `user_modified_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_adreess` (`ip_adreess`) USING HASH,
  KEY `visits_visitsmodels_user_created_id_6f0d9d1f_fk_users_user_id` (`user_created_id`),
  KEY `visits_visitsmodels_user_modified_id_4c410a5b_fk_users_user_id` (`user_modified_id`),
  CONSTRAINT `visits_visitsmodels_user_created_id_6f0d9d1f_fk_users_user_id` FOREIGN KEY (`user_created_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `visits_visitsmodels_user_modified_id_4c410a5b_fk_users_user_id` FOREIGN KEY (`user_modified_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2022-05-29 23:20:01
